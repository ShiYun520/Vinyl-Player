<?php
session_start();

// --- 身份验证部分 (保持不变) ---
$admin_username = 'admin'; // 默认用户名
$admin_password = 'admin123'; // 默认密码，请在生产环境修改！

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username']) && isset($_POST['password'])) {
        if ($_POST['username'] === $admin_username && $_POST['password'] === $admin_password) {
            $_SESSION['admin_logged_in'] = true;
            header('Location: admin.php');
            exit;
        } else {
            $error = '用户名或密码错误';
        }
    }
}

if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: admin.php');
    exit;
}

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    // --- 登录页面 HTML (保持不变) ---
    ?>
    <!DOCTYPE html>
    <html lang="zh-CN">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Vinyl Player - 管理后台登录</title>
        <style>
            /* 定义CSS变量 */
            :root {
                --neumorphic-base: #e0e5ec;
                --neumorphic-light-shadow: #ffffff;
                --neumorphic-dark-shadow: #a3b1c6;
                --text-color: #555;
                --primary-color: #667eea; /* 保持原有的主色调 */
                --primary-color-hover: #5a6fd8;
                --danger-color: #e74c3c;
                --danger-color-hover: #c0392b;
                --success-color: #27ae60;
                --success-color-hover: #229954;
                --info-color: #17a2b8;
                --info-color-hover: #138496;
            }

            body {
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                background-color: var(--neumorphic-base); /* 拟态背景色 */
                margin: 0;
                padding: 0;
                min-height: 100vh; /* Changed from 10vh to 100vh for full-height login page */
                display: flex;
                align-items: center;
                justify-content: center;
                color: var(--text-color);
            }
            .login-container {
                background: var(--neumorphic-base);
                padding: 2rem;
                border-radius: 20px; /* 更大的圆角 */
                /* 拟态凸起效果 */
                box-shadow: 8px 8px 16px var(--neumorphic-dark-shadow),
                            -8px -8px 16px var(--neumorphic-light-shadow);
                width: 100%;
                max-width: 400px;
            }
            .login-header {
                text-align: center;
                margin-bottom: 2rem;
            }
            .login-header h1 {
                margin: 0;
                color: var(--primary-color); /* 标题颜色 */
                font-size: 1.8rem;
            }
            .form-group {
                margin-bottom: 1.5rem;
            }
            label {
                display: block;
                margin-bottom: 0.8rem;
                color: var(--text-color);
                font-weight: 500;
            }
            input[type="text"], input[type="password"] {
                width: 100%;
                padding: 0.9rem;
                border: none; /* 移除边框 */
                border-radius: 10px; /* 圆角 */
                font-size: 1rem;
                box-sizing: border-box;
                background-color: var(--neumorphic-base);
                /* 拟态凹陷效果 */
                box-shadow: inset 4px 4px 8px var(--neumorphic-dark-shadow),
                            inset -4px -4px 8px var(--neumorphic-light-shadow);
                transition: box-shadow 0.2s ease-in-out;
                color: var(--text-color);
            }
            input[type="text"]:focus, input[type="password"]:focus {
                outline: none; /* 移除默认焦点轮廓 */
                /* 焦点时轻微凸起效果，增加反馈 */
                box-shadow: inset 2px 2px 5px var(--neumorphic-dark-shadow),
                            inset -2px -2px 5px var(--neumorphic-light-shadow);
            }

            .login-btn {
                width: 100%;
                padding: 0.9rem;
                background: var(--primary-color);
                color: white;
                border: none;
                border-radius: 15px; /* 圆角 */
                font-size: 1.1rem;
                cursor: pointer;
                margin-top: 1.5rem;
                /* 拟态凸起效果 */
                box-shadow: 5px 5px 10px var(--neumorphic-dark-shadow),
                            -5px -5px 10px var(--neumorphic-light-shadow);
                transition: all 0.2s ease-in-out;
            }
            .login-btn:hover {
                background: var(--primary-color-hover);
                /* 鼠标悬停时凹陷效果 */
                box-shadow: inset 3px 3px 6px var(--neumorphic-dark-shadow),
                            inset -3px -3px 6px var(--neumorphic-light-shadow);
                transform: translateY(1px); /* 模拟按压 */
            }
            .login-btn:active {
                /* 激活时更深的凹陷 */
                box-shadow: inset 5px 5px 10px var(--neumorphic-dark-shadow),
                            inset -5px -5px 10px var(--neumorphic-light-shadow);
                transform: translateY(2px);
            }
            .error {
                color: var(--danger-color);
                margin-bottom: 1.5rem;
                text-align: center;
                font-weight: bold;
            }
            .default-info {
                background: var(--neumorphic-base);
                padding: 1.2rem;
                border-radius: 15px;
                margin-top: 2rem;
                font-size: 0.95rem;
                color: var(--text-color);
                /* 拟态凸起效果 */
                box-shadow: inset 3px 3px 6px var(--neumorphic-dark-shadow),
                            inset -3px -3px 6px var(--neumorphic-light-shadow);
            }
        </style>
    </head>
    <body>
        <div class="login-container">
            <div class="login-header">
                <h1>🎵 Vinyl Player</h1>
                <p>管理后台登录</p>
            </div>
            <?php if (isset($error)): ?>
                <div class="error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            <form method="post">
                <div class="form-group">
                    <label for="username">用户名：</label>
                    <input type="text" id="username" name="username" required>
                </div>
                <div class="form-group">
                    <label for="password">密码：</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <button type="submit" class="login-btn">登录</button>
            </form>
            <div class="default-info">
                <strong>默认登录信息：</strong><br>
                用户名：admin<br>
                密码：admin123
            </div>
        </div>
    </body>
    </html>
    <?php
    exit;
}

// ====== 已登录用户部分 ======

require_once('backend.php'); // Include backend.php after authentication

$songs = loadSongs(); // Directly call loadSongs()
$total_songs = count($songs);
$total_local_size = 0; // Renamed for clarity
$total_local_duration_seconds = 0; // Renamed for clarity

foreach ($songs as $song) {
    // Only calculate size and duration for local files
    if (isset($song['music_filename'])) {
        if (isset($song['duration_seconds'])) {
            $total_local_duration_seconds += $song['duration_seconds'];
        }
        $music_filepath = UPLOAD_DIR . $song['music_filename'];
        if (file_exists($music_filepath)) {
            $total_local_size += filesize($music_filepath);
        }
    }
    if (isset($song['cover_filename'])) { // Covers are always local
        $cover_filepath = COVERS_DIR . $song['cover_filename'];
        if (file_exists($cover_filepath)) {
            $total_local_size += filesize($cover_filepath);
        }
    }
    // External URLs do not contribute to server storage or server-known duration
}

// Function definitions (from backend.php, duplicated here for standalone if needed)
if (!function_exists('formatBytes')) {
    function formatBytes($bytes, $precision = 2) {
        $units = array('B', 'KB', 'MB', 'GB', 'TB');
        for ($i = 0; $bytes > 1024 && $i < count($units) - 1; $i++) { $bytes /= 1024; }
        return round($bytes, $precision) . ' ' . $units[$i];
    }
}
if (!function_exists('formatDuration')) { // Using formatTime from backend.php is better
    function formatDuration($seconds) {
        $seconds = (int) $seconds;
        if ($seconds < 0) return '0:00';
        $hours = floor($seconds / 3600);
        $minutes = floor(($seconds % 3600) / 60);
        $remaining_seconds = $seconds % 60;
        if ($hours > 0) {
            return sprintf('%d:%02d:%02d', $hours, $minutes, $remaining_seconds);
        } else {
            return sprintf('%d:%02d', $minutes, $remaining_seconds);
        }
    }
}

function checkSystemStatus() {
    $status = 'normal';
    // Use constants defined in backend.php
    $upload_dir_abs = __DIR__ . '/' . UPLOAD_DIR;
    $covers_dir_abs = __DIR__ . '/' . COVERS_DIR;

    if (!is_dir($upload_dir_abs)) {
        error_log('UPLOAD_DIR does not exist: ' . $upload_dir_abs);
        $status = 'error';
    }
    if (!is_dir($covers_dir_abs)) {
        error_log('COVERS_DIR does not exist: ' . $covers_dir_abs);
        $status = 'error';
    }
    // Check if directories are writable
    if (!is_writable($upload_dir_abs)) {
        error_log('UPLOAD_DIR is not writable: ' . $upload_dir_abs);
        $status = 'error';
    }
    if (!is_writable($covers_dir_abs)) {
        error_log('COVERS_DIR is not writable: ' . $covers_dir_abs);
        $status = 'error';
    }
    return $status;
}

$system_status = checkSystemStatus();
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vinyl Player - 管理后台</title>
    <style>
        /* 定义CSS变量 */
        :root {
            --neumorphic-base: #e0e5ec;
            --neumorphic-light-shadow: #ffffff;
            --neumorphic-dark-shadow: #a3b1c6;
            --text-color: #555;
            --primary-color: #667eea;
            --primary-color-hover: #5a6fd8;
            --danger-color: #e74c3c;
            --danger-color-hover: #c0392b;
            --success-color: #27ae60;
            --success-color-hover: #229954;
            --info-color: #17a2b8;
            --info-color-hover: #138496;
            --alert-bg-color: #f8d7da;
            --alert-text-color: #721c24;
            --alert-border-color: #f5c6cb;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background-color: var(--neumorphic-base); /* 拟态背景色 */
            line-height: 1.6;
            color: var(--text-color);
        }

        /* 全局拟态元素样式 */
        .neumorphic-element {
            background: var(--neumorphic-base);
            border-radius: 20px;
            box-shadow: 8px 8px 16px var(--neumorphic-dark-shadow),
                        -8px -8px 16px var(--neumorphic-light-shadow);
            transition: all 0.2s ease-in-out;
        }
        .neumorphic-element.inset {
            box-shadow: inset 4px 4px 8px var(--neumorphic-dark-shadow),
                        inset -4px -4px 8px var(--neumorphic-light-shadow);
        }
        .neumorphic-element:hover:not(.no-hover-effect) {
             /* 悬停时轻微按压效果 */
            box-shadow: inset 4px 4px 8px var(--neumorphic-dark-shadow),
                        inset -4px -4px 8px var(--neumorphic-light-shadow);
        }
        .neumorphic-element:active {
            /* 激活时更深的按压效果 */
            box-shadow: inset 6px 6px 12px var(--neumorphic-dark-shadow),
                        inset -6px -6px 12px var(--neumorphic-light-shadow);
            transform: translateY(1px);
        }

        .header {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-color-hover) 100%);
            color: white;
            padding: 1rem 0;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2); /* 头部保持一些深度 */
        }
        .header-content {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .logo {
            font-size: 1.5rem;
            font-weight: bold;
        }
        .logout-btn {
            background: rgba(255,255,255,0.2);
            color: white;
            padding: 0.5rem 1rem;
            text-decoration: none;
            border-radius: 10px;
            transition: background 0.3s;
        }
        .logout-btn:hover {
            background: rgba(255,255,255,0.3);
        }
        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 2rem;
        }
        .alert {
            background: var(--alert-bg-color);
            color: var(--alert-text-color);
            border: 1px solid var(--alert-border-color);
            padding: 1rem;
            border-radius: 15px; /* 拟态圆角 */
            margin-bottom: 2rem;
            box-shadow: 3px 3px 6px var(--neumorphic-dark-shadow); /* 稍微凸起 */
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        .stat-card {
            padding: 1.5rem;
            text-align: center;
            /* 拟态凸起效果 */
            background: var(--neumorphic-base);
            border-radius: 20px;
            box-shadow: 6px 6px 12px var(--neumorphic-dark-shadow),
                        -6px -6px 12px var(--neumorphic-light-shadow);
        }
        .stat-number {
            font-size: 2.2rem;
            font-weight: bold;
            color: var(--primary-color);
            margin-bottom: 0.5rem;
        }
        .stat-number.error { color: var(--danger-color); }
        .stat-number.success { color: var(--success-color); }
        .stat-label {
            color: var(--text-color);
            font-size: 0.95rem;
        }
        .content-section {
            /* 拟态凸起效果 */
            background: var(--neumorphic-base);
            border-radius: 20px;
            box-shadow: 8px 8px 16px var(--neumorphic-dark-shadow),
                        -8px -8px 16px var(--neumorphic-light-shadow);
            overflow: hidden;
            margin-bottom: 2rem;
        }
        .section-header {
            background: var(--neumorphic-base); /* 保持与主体一致 */
            padding: 1rem 1.5rem;
            border-bottom: 1px solid rgba(0,0,0,0.1); /* 柔和分割线 */
            display: flex;
            justify-content: space-between;
            align-items: center;
            /* 头部可以稍微内凹，或保持无 shadow */
            box-shadow: inset 2px 2px 5px var(--neumorphic-dark-shadow);
            border-top-left-radius: 20px;
            border-top-right-radius: 20px;
        }
        .section-header h3 {
            color: var(--text-color);
        }
        .section-content {
            padding: 1.5rem;
        }
        .songs-table {
            width: 100%;
            border-collapse: collapse;
            background: var(--neumorphic-base); /* 表格背景 */
            border-radius: 15px; /* 表格整体圆角 */
            overflow: hidden; /* 确保圆角可见 */
        }
        .songs-table th, .songs-table td {
            padding: 0.9rem;
            text-align: left;
            border-bottom: 1px solid rgba(0,0,0,0.1); /* 柔和分割线 */
            color: var(--text-color);
        }
        .songs-table th {
            background: var(--neumorphic-base); /* 表头背景 */
            font-weight: 600;
        }
        .songs-table tbody tr:last-child td {
            border-bottom: none; /* 最后一行无底边框 */
        }
        .songs-table tbody tr:hover {
            background-color: rgba(0,0,0,0.03); /* 鼠标悬停效果 */
        }

        .song-cover {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 10px; /* 圆角 */
            box-shadow: 2px 2px 5px var(--neumorphic-dark-shadow);
        }
        .no-cover {
            width: 50px;
            height: 50px;
            background: rgba(0,0,0,0.05); /* 浅色背景 */
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--text-color);
            font-size: 1.2rem;
            box-shadow: inset 2px 2px 5px var(--neumorphic-dark-shadow); /* 凹陷效果 */
        }
        /* Style for external link icon */
        .external-link-icon {
            font-size: 1.5rem;
            color: var(--primary-color);
        }

        .btn {
            padding: 0.7rem 1.2rem;
            background: var(--primary-color);
            color: white;
            text-decoration: none;
            border-radius: 15px; /* 圆角 */
            border: none;
            cursor: pointer;
            display: inline-block;
            font-size: 1rem;
            margin: 0.25rem;
            /* 拟态凸起效果 */
            box-shadow: 3px 3px 6px var(--neumorphic-dark-shadow),
                        -3px -3px 6px var(--neumorphic-light-shadow);
            transition: all 0.2s ease-in-out;
            outline: none; /* 移除焦点轮廓 */
        }
        .btn:hover {
            background: var(--primary-color-hover);
            /* 悬停时凹陷 */
            box-shadow: inset 2px 2px 5px var(--neumorphic-dark-shadow),
                        inset -2px -2px 5px var(--neumorphic-light-shadow);
            transform: translateY(1px);
        }
        .btn:active {
            box-shadow: inset 3px 3px 6px var(--neumorphic-dark-shadow),
                        inset -3px -3px 6px var(--neumorphic-light-shadow);
            transform: translateY(2px);
        }
        .btn-danger { background: var(--danger-color); }
        .btn-danger:hover { background: var(--danger-color-hover); }
        .btn-success { background: var(--success-color); }
        .btn-success:hover { background: var(--success-color-hover); }
        .btn-info { background: var(--info-color); }
        .btn-info:hover { background: var(--info-color-hover); } /* New for edit button */
        .btn-small {
            padding: 0.5rem 0.9rem;
            font-size: 0.85rem;
            border-radius: 10px; /* 小按钮也圆角 */
            box-shadow: 2px 2px 4px var(--neumorphic-dark-shadow),
                        -2px -2px 4px var(--neumorphic-light-shadow);
        }
        .btn-small:hover {
            box-shadow: inset 1px 1px 3px var(--neumorphic-dark-shadow),
                        inset -1px -1px 3px var(--neumorphic-light-shadow);
            transform: translateY(0.5px);
        }
        .btn-small:active {
            box-shadow: inset 2px 2px 4px var(--neumorphic-dark-shadow),
                        inset -2px -2px 4px var(--neumorphic-light-shadow);
            transform: translateY(1px);
        }

        .empty-state {
            text-align: center;
            padding: 3rem 1rem;
            color: var(--text-color);
            background: var(--neumorphic-base);
            border-radius: 20px;
            box-shadow: inset 4px 4px 8px var(--neumorphic-dark-shadow),
                        inset -4px -4px 8px var(--neumorphic-light-shadow);
        }
        .empty-state h3 { margin-bottom: 1rem; color: var(--text-color); }
        .actions { text-align: center; margin-top: 2rem; }
        .loading { text-align: center; padding: 2rem; color: var(--text-color); }
        .refresh-btn { background: var(--info-color); }
        .refresh-btn:hover { background: var(--info-color-hover); }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.6);
            justify-content: center;
            align-items: center;
        }
        .modal-content {
            background-color: var(--neumorphic-base);
            margin: auto;
            padding: 25px; /* 增加内边距 */
            border-radius: 25px; /* 大圆角 */
            /* 拟态凸起效果 */
            box-shadow: 10px 10px 20px var(--neumorphic-dark-shadow),
                        -10px -10px 20px var(--neumorphic-light-shadow);
            width: 90%;
            max-width: 550px; /* 稍微大一点 */
            position: relative;
        }
        .close-button {
            color: var(--text-color);
            position: absolute;
            top: 15px;
            right: 20px;
            font-size: 32px; /* 更大 */
            font-weight: bold;
            cursor: pointer;
            width: 40px; /* 使其可点击区域更大 */
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%; /* 圆形按钮 */
            background: var(--neumorphic-base);
            box-shadow: 3px 3px 6px var(--neumorphic-dark-shadow),
                        -3px -3px 6px var(--neumorphic-light-shadow);
            transition: all 0.2s ease-in-out;
        }
        .close-button:hover,
        .close-button:focus {
            color: var(--primary-color);
            box-shadow: inset 2px 2px 5px var(--neumorphic-dark-shadow),
                        inset -2px -2px 5px var(--neumorphic-light-shadow);
        }
        .modal-body label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
            color: var(--text-color);
        }
        .modal-body input[type="text"] {
            width: 100%;
            padding: 12px; /* 增加内边距 */
            margin-bottom: 18px; /* 增加间距 */
            border: none;
            border-radius: 12px; /* 圆角 */
            background-color: var(--neumorphic-base);
            /* 拟态凹陷效果 */
            box-shadow: inset 4px 4px 8px var(--neumorphic-dark-shadow),
                        inset -4px -4px 8px var(--neumorphic-light-shadow);
            transition: box-shadow 0.2s ease-in-out;
            color: var(--text-color);
        }
        .modal-body input[type="text"]:focus {
            outline: none;
            box-shadow: inset 2px 2px 5px var(--neumorphic-dark-shadow),
                        inset -2px -2px 5px var(--neumorphic-light-shadow);
        }
        .modal-footer {
            text-align: right;
            padding-top: 20px;
            border-top: 1px solid rgba(0,0,0,0.1);
            margin-top: 20px;
        }
        .modal-footer .btn {
            margin-left: 15px;
        }
        .modal-message {
            margin-top: 15px;
            padding: 12px;
            border-radius: 10px;
            display: none;
            text-align: center;
            font-weight: bold;
        }
        .modal-message.success {
            background-color: var(--success-color);
            color: white;
            box-shadow: inset 3px 3px 6px rgba(0,0,0,0.2), inset -3px -3px 6px rgba(255,255,255,0.2);
        }
        .modal-message.error {
            background-color: var(--danger-color);
            color: white;
            box-shadow: inset 3px 3px 6px rgba(0,0,0,0.2), inset -3px -3px 6px rgba(255,255,255,0.2);
        }
        .modal-message.info { /* For "processing" message */
            background-color: var(--info-color);
            color: white;
            box-shadow: inset 3px 3px 6px rgba(0,0,0,0.2), inset -3px -3px 6px rgba(255,255,255,0.2);
        }


        @media (max-width: 768px) {
            .header-content { padding: 0 1rem; }
            .container { padding: 0 1rem; }
            .stats-grid { grid-template-columns: 1fr; }
            .songs-table { font-size: 0.9rem; }
            .songs-table th, .songs-table td { padding: 0.7rem; }
            .song-cover, .no-cover { width: 40px; height: 40px; border-radius: 8px;}
            .btn { padding: 0.6rem 1rem; font-size: 0.9rem; border-radius: 12px;}
            .btn-small { padding: 0.4rem 0.7rem; font-size: 0.8rem; border-radius: 8px;}
            .modal-content { padding: 20px; border-radius: 20px;}
            .close-button { top: 10px; right: 15px; font-size: 28px; width: 35px; height: 35px;}
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="header-content">
            <div class="logo">🎵 Vinyl Player 管理后台</div>
            <div>
                <button onclick="refreshData()" class="btn refresh-btn btn-small">刷新数据</button>
                <a href="?logout=1" class="logout-btn">退出登录</a>
            </div>
        </div>
    </div>

    <div class="container">
        <!-- 系统状态警告 -->
        <?php if ($system_status === 'error'): ?>
        <div class="alert">
            ⚠️ 系统状态异常：请检查 `music_files` 和 `covers` 目录是否存在且可写
        </div>
        <?php endif; ?>

        <!-- 统计卡片 -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-number"><?php echo $total_songs; ?></div>
                <div class="stat-label">总歌曲数</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo formatBytes($total_local_size); ?></div>
                <div class="stat-label">本地文件大小</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo formatDuration($total_local_duration_seconds); ?></div>
                <div class="stat-label">本地歌曲总时长</div>
            </div>
            <div class="stat-card">
                <div class="stat-number <?php echo $system_status === 'normal' ? 'success' : 'error'; ?>">
                    <?php echo $system_status === 'normal' ? '正常' : '异常'; ?>
                </div>
                <div class="stat-label">系统状态</div>
            </div>
        </div>

        <!-- 歌曲列表 -->
        <div class="content-section">
            <div class="section-header">
                <h3>歌曲管理 (<?php echo $total_songs; ?> 首)</h3>
                <div class="flex-gap-2"> <!-- Added a flex container for buttons -->
                    <button onclick="openDownloadByUrlModal()" class="btn btn-success btn-small">
                        <span style="font-size: 1.2em; vertical-align: middle;">📥</span> 下载并添加
                    </button>
                    <button onclick="openAddExternalLinkModal()" class="btn btn-info btn-small">
                        <span style="font-size: 1.2em; vertical-align: middle;">🔗</span> 添加外部链接
                    </button>
                    <button onclick="deleteAllSongs()" class="btn btn-danger btn-small" <?php echo $total_songs === 0 ? 'disabled' : ''; ?>>
                        清空所有歌曲
                    </button>
                </div>
            </div>
            <div class="section-content">
                <?php if (empty($songs)): ?>
                    <div class="empty-state">
                        <h3>暂无歌曲</h3>
                        <p>还没有添加任何音乐文件，请上传或添加外部链接。</p>
                        <a href="index.html" class="btn" style="margin-top: 1rem;">前往播放器</a>
                        <div style="margin-top: 1rem;">
                            <button onclick="openDownloadByUrlModal()" class="btn btn-success">
                                <span style="font-size: 1.2em; vertical-align: middle;">📥</span> 下载并添加
                            </button>
                            <button onclick="openAddExternalLinkModal()" class="btn btn-info">
                                <span style="font-size: 1.2em; vertical-align: middle;">🔗</span> 添加外部链接
                            </button>
                        </div>
                    </div>
                <?php else: ?>
                    <div style="overflow-x: auto;">
                        <table class="songs-table">
                            <thead>
                                <tr>
                                    <th>封面</th>
                                    <th>标题</th>
                                    <th>艺术家</th>
                                    <th>专辑</th>
                                    <th>时长</th>
                                    <th>来源/原文件名</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($songs as $index => $song): ?>
                                    <tr data-song-id="<?php echo htmlspecialchars($song['id']); ?>">
                                        <td>
                                            <?php if (isset($song['music_filename']) && isset($song['cover_url']) && $song['cover_url']): ?>
                                                <img src="<?php echo htmlspecialchars($song['cover_url']); ?>"
                                                     alt="封面" class="song-cover"
                                                     onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                                                <div class="no-cover" style="display: none;">♪</div>
                                            <?php elseif (isset($song['external_url'])): ?>
                                                <div class="no-cover" title="外部链接"><i class="fas fa-link external-link-icon"></i></div>
                                            <?php else: ?>
                                                <div class="no-cover">♪</div>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo htmlspecialchars($song['title'] ?? '未知标题'); ?></td>
                                        <td><?php echo htmlspecialchars($song['artist'] ?? '未知艺术家'); ?></td>
                                        <td><?php echo htmlspecialchars($song['album'] ?? (isset($song['external_url']) ? '外部链接' : '未知专辑')); ?></td>
                                        <td><?php echo htmlspecialchars($song['duration'] ?? '0:00'); ?></td>
                                        <td style="font-size: 0.8em; color: var(--text-color);">
                                            <?php if (isset($song['music_filename'])): ?>
                                                <span title="<?php echo htmlspecialchars($song['music_filename']); ?>"><?php echo htmlspecialchars($song['original_filename'] ?? $song['music_filename']); ?></span>
                                            <?php elseif (isset($song['external_url'])): ?>
                                                <span title="<?php echo htmlspecialchars($song['external_url']); ?>">外部链接</span>
                                            <?php else: ?>
                                                未知来源
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <button class="btn btn-small"
                                                    onclick="playSong('<?php echo htmlspecialchars($song['url'] ?? ''); ?>')">
                                                播放
                                            </button>
                                            <!-- 新增编辑按钮 -->
                                            <button class="btn btn-info btn-small"
                                                    onclick="openEditModal('<?php echo htmlspecialchars($song['id']); ?>')">
                                                编辑
                                            </button>
                                            <button class="btn btn-danger btn-small"
                                                    onclick="deleteSong('<?php echo htmlspecialchars($song['id']); ?>', '<?php echo htmlspecialchars($song['title'] ?? ''); ?>')">
                                                删除
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- 快捷操作 -->
        <div class="actions">
            <a href="index.html" class="btn">前往播放器</a>
            <a href="backend.php?action=list" class="btn" target="_blank">查看API数据</a>
            <button onclick="checkSystemHealth()" class="btn btn-success">系统检测</button>
        </div>
    </div>

    <!-- 音频播放器（隐藏） -->
    <audio id="audioPlayer" controls style="display: none;"></audio>

    <!-- Download by URL Modal (原来的“从URL添加歌曲”，现在改为下载功能) -->
    <div id="downloadByUrlModal" class="modal">
        <div class="modal-content">
            <span class="close-button" onclick="closeDownloadByUrlModal()">&times;</span>
            <h2>下载并添加歌曲</h2>
            <div class="modal-body">
                <p>从外部URL下载音频文件到服务器。支持元数据（标题、艺术家、专辑、封面）提取。</p>
                <label for="downloadMusicUrl">音乐文件 URL: <span style="color:red">*</span></label>
                <input type="text" id="downloadMusicUrl" placeholder="例如: http://example.com/audio/mysong.mp3">

                <label for="downloadMusicTitle">标题 (可选):</label>
                <input type="text" id="downloadMusicTitle" placeholder="默认音乐名或自定义">

                <label for="downloadMusicArtist">艺术家 (可选):</label>
                <input type="text" id="downloadMusicArtist" placeholder="默认歌手名或自定义">

                <label for="downloadMusicAlbum">专辑 (可选):</label>
                <input type="text" id="downloadMusicAlbum" placeholder="默认专辑名或自定义">

                <div id="downloadModalMessage" class="modal-message"></div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-danger" onclick="closeDownloadByUrlModal()">取消</button>
                <button class="btn btn-success" id="downloadUrlBtn" onclick="downloadSongByUrl()">下载并添加</button>
            </div>
        </div>
    </div>

    <!-- Add External Link Modal (新增，只记录URL不下载) -->
    <div id="addExternalLinkModal" class="modal">
        <div class="modal-content">
            <span class="close-button" onclick="closeAddExternalLinkModal()">&times;</span>
            <h2>添加外部音乐链接</h2>
            <div class="modal-body">
                <p>请输入直接指向音频文件（如 .mp3, .wav）的 URL。播放时将直接从该 URL 流式加载，文件不会下载到服务器。</p>
                <label for="externalLinkUrl">音乐文件 URL: <span style="color:red">*</span></label>
                <input type="text" id="externalLinkUrl" placeholder="例如: http://example.com/audio/mysong.mp3">

                <label for="externalLinkTitle">标题 (可选):</label>
                <input type="text" id="externalLinkTitle" placeholder="默认为 URL 的文件名或自定义">

                <label for="externalLinkArtist">艺术家 (可选):</label>
                <input type="text" id="externalLinkArtist" placeholder="默认为“未知艺术家”或自定义">

                <div id="externalLinkModalMessage" class="modal-message"></div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-danger" onclick="closeAddExternalLinkModal()">取消</button>
                <button class="btn btn-success" id="addExternalLinkBtn" onclick="addExternalLink()">添加到列表</button>
            </div>
        </div>
    </div>

    <!-- Edit Song Modal (保持不变) -->
    <div id="editSongModal" class="modal">
        <div class="modal-content">
            <span class="close-button" onclick="closeEditModal()">&times;</span>
            <h2>编辑歌曲信息</h2>
            <div class="modal-body">
                <input type="hidden" id="editSongId"> <!-- 隐藏域用于存储歌曲ID -->
                
                <label for="editTitle">标题:</label>
                <input type="text" id="editTitle">

                <label for="editArtist">艺术家:</label>
                <input type="text" id="editArtist">

                <label for="editAlbum">专辑:</label>
                <input type="text" id="editAlbum">

                <div id="editModalMessage" class="modal-message"></div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-danger" onclick="closeEditModal()">取消</button>
                <button class="btn btn-success" id="saveEditBtn" onclick="saveEditedSong()">保存</button>
            </div>
        </div>
    </div>


    <script>
        // 刷新数据
        function refreshData() {
            location.reload();
        }

        // 删除单个歌曲
        function deleteSong(songId, title) {
            if (!confirm(`确定要删除歌曲 "${title}" 吗？此操作不可撤销。`)) {
                return;
            }

            const button = event.target;
            const originalText = button.textContent;
            button.textContent = '删除中...';
            button.disabled = true;

            fetch(`backend.php?action=delete&id=${encodeURIComponent(songId)}`, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.message) {
                    const row = button.closest('tr');
                    if (row) {
                        row.remove();
                    }

                    updateSongCount(); // Update counts
                    alert(`歌曲 "${title}" 删除成功！`); // Add success alert
                } else {
                    alert('删除失败：' + (data.error || '未知错误'));
                    button.textContent = originalText;
                    button.disabled = false;
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('删除失败：网络错误');
                button.textContent = originalText;
                button.disabled = false;
            });
        }

        // 播放歌曲
        function playSong(url) {
            if (!url) {
                alert('歌曲URL无效');
                return;
            }

            const player = document.getElementById('audioPlayer');
            player.src = url;
            player.play().catch(error => {
                console.error('播放失败:', error);
                alert('播放失败，请检查文件是否存在或链接是否有效');
            });
        }

        // 更新歌曲计数 (以及可能更新的UI状态)
        function updateSongCount() {
            // Re-fetch the data to get accurate counts and sizes, as delete/add operations change the backend state
            fetch('backend.php?action=list')
                .then(response => response.json())
                .then(songsData => {
                    const totalSongs = songsData.length;
                    document.querySelector('.stat-card:nth-child(1) .stat-number').textContent = totalSongs;
                    document.querySelector('.section-header h3').textContent = `歌曲管理 (${totalSongs} 首)`;

                    // For now, if no songs, trigger a full reload to show empty state.
                    // A more advanced approach would dynamically update the table and stats
                    if (totalSongs === 0) {
                        location.reload(); 
                    } else {
                         const clearAllBtn = document.querySelector('button[onclick="deleteAllSongs()"]');
                         if (clearAllBtn) clearAllBtn.disabled = (totalSongs === 0);
                    }
                })
                .catch(error => {
                    console.error('更新歌曲计数失败:', error);
                    // Fallback if API fails
                    const currentRows = document.querySelectorAll('.songs-table tbody tr').length;
                    document.querySelector('.stat-card:nth-child(1) .stat-number').textContent = currentRows;
                    document.querySelector('.section-header h3').textContent = `歌曲管理 (${currentRows} 首)`;
                    const clearAllBtn = document.querySelector('button[onclick="deleteAllSongs()"]');
                    if (clearAllBtn) clearAllBtn.disabled = (currentRows === 0);
                });
        }

        // 清空所有歌曲
        function deleteAllSongs() {
            const songCount = document.querySelector('.stat-card:nth-child(1) .stat-number').textContent;
            if (parseInt(songCount) === 0) {
                alert('没有歌曲需要删除');
                return;
            }

            if (!confirm(`确定要删除所有 ${songCount} 首歌曲吗？此操作不可撤销！这会删除所有本地文件和所有记录！`)) {
                return;
            }

            fetch('backend.php?action=delete_all', { method: 'POST' })
                .then(response => response.json())
                .then(data => {
                    if (data.message) {
                        alert(data.message);
                        location.reload(); // Reload to show empty state and updated stats
                    } else {
                        alert('清空所有歌曲失败：' + (data.error || '未知错误'));
                    }
                })
                .catch(error => {
                    console.error('清空所有歌曲出错:', error);
                    alert('清空所有歌曲失败：网络错误');
                });
        }


        // 系统健康检查
        function checkSystemHealth() {
            fetch('backend.php?action=list')
                .then(response => response.json())
                .then(data => {
                    if (Array.isArray(data)) {
                        alert(`✅ 系统运行正常\n\n📊 统计信息：\n• API响应正常\n• 歌曲列表加载成功\n• 当前共有 ${data.length} 首歌曲`);
                    } else {
                        alert(`⚠️ 系统状态异常\n\nAPI返回了非预期的数据格式`);
                    }
                })
                .catch(error => {
                    console.error('健康检查失败:', error);
                    alert(`❌ 系统检测失败\n\n错误信息：\n${error.message}\n\n请检查：\n• backend.php 是否正常运行\n• 网络连接是否正常\n• 服务器配置是否正确`);
                });
        }

        // --- Download by URL Modal Functions (原来的 modal 现在用于下载) ---
        const downloadByUrlModal = document.getElementById('downloadByUrlModal');
        const downloadMusicUrlInput = document.getElementById('downloadMusicUrl');
        const downloadMusicTitleInput = document.getElementById('downloadMusicTitle');
        const downloadMusicArtistInput = document.getElementById('downloadMusicArtist');
        const downloadMusicAlbumInput = document.getElementById('downloadMusicAlbum'); // Album input back for download
        const downloadModalMessage = document.getElementById('downloadModalMessage');
        const downloadUrlBtn = document.getElementById('downloadUrlBtn');

        function openDownloadByUrlModal() {
            downloadByUrlModal.style.display = 'flex';
            downloadMusicUrlInput.value = '';
            downloadMusicTitleInput.value = '';
            downloadMusicArtistInput.value = '';
            downloadMusicAlbumInput.value = ''; // Clear album
            downloadModalMessage.style.display = 'none';
            downloadModalMessage.className = 'modal-message';
            downloadUrlBtn.disabled = false;
            downloadUrlBtn.textContent = '下载并添加';
        }

        function closeDownloadByUrlModal() {
            downloadByUrlModal.style.display = 'none';
        }

        // Re-used helper function for modal messages (can be for any modal)
        function showModalMessage(message, type, modalMsgElement) {
            modalMsgElement.textContent = message;
            modalMsgElement.className = `modal-message ${type}`;
            modalMsgElement.style.display = 'block';
        }

        function downloadSongByUrl() {
            const url = downloadMusicUrlInput.value.trim();
            const title = downloadMusicTitleInput.value.trim();
            const artist = downloadMusicArtistInput.value.trim();
            const album = downloadMusicAlbumInput.value.trim();

            if (!url) {
                showModalMessage('URL 不能为空！', 'error', downloadModalMessage);
                return;
            }

            downloadUrlBtn.disabled = true;
            downloadUrlBtn.textContent = '下载中...';
            showModalMessage('正在下载并处理歌曲，请稍候... (这可能需要一些时间)', 'info', downloadModalMessage);

            const formData = new FormData();
            formData.append('url', url);
            if (title !== '') {
                formData.append('title', title);
            }
            if (artist !== '') {
                formData.append('artist', artist);
            }
            if (album !== '') { // Only send album if not empty
                formData.append('album', album);
            }

            fetch('backend.php?action=add_by_url', { // This calls the download action
                method: 'POST',
                body: formData
            })
            .then(response => {
                // Ensure response is JSON even if error
                if (!response.ok) {
                    return response.json().then(err => {
                        throw new Error(err.error || `HTTP error! status: ${response.status}`);
                    }).catch(() => {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    });
                }
                return response.json();
            })
            .then(data => {
                if (data.message) {
                    showModalMessage(data.message, 'success', downloadModalMessage);
                    setTimeout(() => {
                        closeDownloadByUrlModal();
                        refreshData(); // Reload to show the new song
                    }, 1500);
                } else {
                    showModalMessage('下载失败: ' + (data.error || '未知错误'), 'error', downloadModalMessage);
                    downloadUrlBtn.disabled = false;
                    downloadUrlBtn.textContent = '下载并添加';
                }
            })
            .catch(error => {
                console.error('Error downloading song by URL:', error);
                showModalMessage('请求失败，网络错误或服务器无响应。' + (error.message || ''), 'error', downloadModalMessage);
                downloadUrlBtn.disabled = false;
                downloadUrlBtn.textContent = '下载并添加';
            });
        }

        // --- Add External Link Modal Functions (新的 modal 只记录 URL) ---
        const addExternalLinkModal = document.getElementById('addExternalLinkModal');
        const externalLinkUrlInput = document.getElementById('externalLinkUrl');
        const externalLinkTitleInput = document.getElementById('externalLinkTitle');
        const externalLinkArtistInput = document.getElementById('externalLinkArtist');
        const externalLinkModalMessage = document.getElementById('externalLinkModalMessage');
        const addExternalLinkBtn = document.getElementById('addExternalLinkBtn');

        function openAddExternalLinkModal() {
            addExternalLinkModal.style.display = 'flex';
            externalLinkUrlInput.value = '';
            externalLinkTitleInput.value = '';
            externalLinkArtistInput.value = '';
            externalLinkModalMessage.style.display = 'none';
            externalLinkModalMessage.className = 'modal-message';
            addExternalLinkBtn.disabled = false;
            addExternalLinkBtn.textContent = '添加到列表';
        }

        function closeAddExternalLinkModal() {
            addExternalLinkModal.style.display = 'none';
        }

        function addExternalLink() {
            const url = externalLinkUrlInput.value.trim();
            const title = externalLinkTitleInput.value.trim();
            const artist = externalLinkArtistInput.value.trim();

            if (!url) {
                showModalMessage('URL 不能为空！', 'error', externalLinkModalMessage);
                return;
            }

            addExternalLinkBtn.disabled = true;
            addExternalLinkBtn.textContent = '添加中...';
            showModalMessage('正在添加歌曲...', 'info', externalLinkModalMessage);

            fetch('backend.php?action=add_url', { // This calls the add_url action (no download)
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ url: url, title: title, artist: artist })
            })
            .then(response => {
                if (!response.ok) {
                    return response.json().then(err => {
                        throw new Error(err.error || `HTTP error! status: ${response.status}`);
                    }).catch(() => {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    });
                }
                return response.json();
            })
            .then(data => {
                if (data.message) {
                    showModalMessage(data.message, 'success', externalLinkModalMessage);
                    setTimeout(() => {
                        closeAddExternalLinkModal();
                        refreshData(); // Reload to show the new song
                    }, 1500);
                } else {
                    showModalMessage('添加失败: ' + (data.error || '未知错误'), 'error', externalLinkModalMessage);
                    addExternalLinkBtn.disabled = false;
                    addExternalLinkBtn.textContent = '添加到列表';
                }
            })
            .catch(error => {
                console.error('Error adding external link:', error);
                showModalMessage('请求失败，网络错误或服务器无响应。' + (error.message || ''), 'error', externalLinkModalMessage);
                addExternalLinkBtn.disabled = false;
                addExternalLinkBtn.textContent = '添加到列表';
            });
        }


        // --- Edit Song Modal Functions (保持不变) ---
        const editSongModal = document.getElementById('editSongModal');
        const editSongIdInput = document.getElementById('editSongId');
        const editTitleInput = document.getElementById('editTitle');
        const editArtistInput = document.getElementById('editArtist');
        const editAlbumInput = document.getElementById('editAlbum');
        const editModalMessage = document.getElementById('editModalMessage');
        const saveEditBtn = document.getElementById('saveEditBtn');

        function openEditModal(songId) {
            editModalMessage.style.display = 'none'; // Hide previous messages
            saveEditBtn.disabled = false; // Enable button
            saveEditBtn.textContent = '保存';

            // Fetch song details from backend
            fetch(`backend.php?action=get_song&id=${encodeURIComponent(songId)}`)
                .then(response => {
                    if (!response.ok) {
                        throw new Error('网络响应失败: ' + response.statusText);
                    }
                    return response.json();
                })
                .then(songData => {
                    if (songData.error) {
                        showModalMessage('获取歌曲信息失败: ' + songData.error, 'error', editModalMessage);
                        return;
                    }
                    editSongIdInput.value = songData.id;
                    editTitleInput.value = songData.title || '';
                    editArtistInput.value = songData.artist || '';
                    editAlbumInput.value = songData.album || '';
                    editSongModal.style.display = 'flex'; // Show modal
                })
                .catch(error => {
                    console.error('Error fetching song for edit:', error);
                    showModalMessage('获取歌曲信息失败: ' + error.message, 'error', editModalMessage);
                });
        }

        function closeEditModal() {
            editSongModal.style.display = 'none';
        }

        function saveEditedSong() {
            const songId = editSongIdInput.value;
            const newTitle = editTitleInput.value.trim();
            const newArtist = editArtistInput.value.trim();
            const newAlbum = editAlbumInput.value.trim();

            if (!songId) {
                showModalMessage('歌曲ID缺失，无法保存。', 'error', editModalMessage);
                return;
            }

            saveEditBtn.disabled = true;
            saveEditBtn.textContent = '保存中...';
            showModalMessage('正在保存修改...', 'info', editModalMessage);

            fetch('backend.php?action=update_song', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    id: songId,
                    title: newTitle,
                    artist: newArtist,
                    album: newAlbum
                })
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('网络响应失败: ' + response.statusText);
                }
                return response.json();
            })
            .then(data => {
                if (data.message) {
                    showModalMessage(data.message, 'success', editModalMessage);
                    // Update the table row dynamically instead of full reload for smoother UX
                    const row = document.querySelector(`tr[data-song-id="${songId}"]`);
                    if (row) {
                        row.children[1].textContent = newTitle;
                        row.children[2].textContent = newArtist;
                        row.children[3].textContent = newAlbum;
                    }
                    setTimeout(() => {
                        closeEditModal();
                    }, 1500);
                } else {
                    showModalMessage('保存失败: ' + (data.error || '未知错误'), 'error', editModalMessage);
                    saveEditBtn.disabled = false;
                    saveEditBtn.textContent = '保存';
                }
            })
            .catch(error => {
                console.error('Error saving edited song:', error);
                showModalMessage('请求失败，网络错误或服务器无响应。', 'error', editModalMessage);
                saveEditBtn.disabled = false;
                saveEditBtn.textContent = '保存';
            });
        }


        // 页面加载完成后的初始化
        document.addEventListener('DOMContentLoaded', function() {
            console.log('Vinyl Player Admin Panel loaded');
            // updateSongCount(); // Initial update on page load. Removed as PHP already calculates it.

            // Add event listener to close modal if clicking outside
            window.addEventListener('click', function(event) {
                if (event.target == downloadByUrlModal) {
                    closeDownloadByUrlModal();
                }
                if (event.target == addExternalLinkModal) {
                    closeAddExternalLinkModal();
                }
                if (event.target == editSongModal) {
                    closeEditModal();
                }
            });

            // Add keyboard shortcuts
            document.addEventListener('keydown', function(e) {
                if ((e.ctrlKey && e.key === 'r') || e.key === 'F5') {
                    e.preventDefault();
                    refreshData();
                }
                if (e.ctrlKey && e.key === 'h') {
                    e.preventDefault();
                    checkSystemHealth();
                }
            });
        });
    </script>
</body>
</html>
