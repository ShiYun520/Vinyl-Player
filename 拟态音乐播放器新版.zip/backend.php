<?php

session_start(); // Admin.php 包含了 session_start(), backend.php 如果需要独立调用也应包含，但通常只在 admin.php 的 context 中被 include

header("Access-Control-Allow-Origin: *");
error_reporting(E_ALL); // 报告所有错误
ini_set('display_errors', 1); // 调试时显示错误，生产环境应设为 0
date_default_timezone_set('UTC'); // 设置时区，避免日期/时间函数警告

// 引入 getID3 库
// 请确保 getid3 目录在 backend.php 同级目录
require_once('getid3/getid3.php');

// --- 配置常量 ---
const UPLOAD_DIR = 'music_files/'; // 音乐文件存储目录
const COVERS_DIR = 'covers/';     // 封面图片存储目录
const SONGS_FILE = 'songs.json';  // 歌曲数据文件
const ALLOWED_EXTENSIONS = ['mp3', 'wav', 'ogg', 'flac', 'aac']; // 允许的音乐文件扩展名
const MAX_DOWNLOAD_SIZE = 100 * 1024 * 1024; // 100 MB，用于 URL 下载功能的文件大小限制

// --- 辅助函数 ---

// 确保目录存在且可写
function ensureDirsExist() {
    $upload_dir_abs = __DIR__ . '/' . UPLOAD_DIR;
    $covers_dir_abs = __DIR__ . '/' . COVERS_DIR;

    // 检查并创建 UPLOAD_DIR
    if (!is_dir($upload_dir_abs)) {
        if (!mkdir($upload_dir_abs, 0775, true)) {
            error_log("Error: Failed to create upload directory: " . $upload_dir_abs);
            // 如果无法创建，后续操作将失败
        }
    }
    // 检查 UPLOAD_DIR 是否可写
    if (!is_writable($upload_dir_abs)) {
        error_log("Error: Upload directory not writable: " . $upload_dir_abs);
    }

    // 检查并创建 COVERS_DIR
    if (!is_dir($covers_dir_abs)) {
        if (!mkdir($covers_dir_abs, 0775, true)) {
            error_log("Error: Failed to create covers directory: " . $covers_dir_abs);
        }
    }
    // 检查 COVERS_DIR 是否可写
    if (!is_writable($covers_dir_abs)) {
        error_log("Error: Covers directory not writable: " . $covers_dir_abs);
    }
}
ensureDirsExist(); // 首次加载时调用，确保目录存在且可写

// 加载歌曲列表
function loadSongs() {
    $songs_file_abs = __DIR__ . '/' . SONGS_FILE;
    if (!file_exists($songs_file_abs) || filesize($songs_file_abs) === 0) {
        return []; // 文件不存在或为空时返回空数组
    }

    $json_data = file_get_contents($songs_file_abs);
    if ($json_data === false) {
         error_log("Error reading songs.json file.");
         return []; // 读取失败返回空数组
    }

    $songs = json_decode($json_data, true);

    if (json_last_error() !== JSON_ERROR_NONE) {
        error_log("Error decoding songs.json: " . json_last_error_msg());
        // 尝试备份损坏的文件并返回空数组
        rename($songs_file_abs, $songs_file_abs . '.bak_' . time());
        error_log("Corrupted songs.json backed up. Creating new empty file.");
        saveSongs([]); // 重新初始化为空数组
        return [];
    }
    if (!is_array($songs)) {
         error_log("songs.json content is not an array after decoding.");
         // 尝试备份损坏的文件并返回空数组
         rename($songs_file_abs, $songs_file_abs . '.bak_' . time());
         error_log("Corrupted songs.json (not array) backed up. Creating new empty file.");
         saveSongs([]); // 重新初始化为空数组
         return [];
    }
    return $songs;
}

// 保存歌曲列表
function saveSongs(array $songs) {
    $songs_file_abs = __DIR__ . '/' . SONGS_FILE;
    $json_data = json_encode($songs, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE); // 格式化输出，支持中文
    if ($json_data === false) {
        error_log("Error encoding songs array to JSON: " . json_last_error_msg());
        return false;
    }
    // 使用临时文件进行原子写入，防止文件损坏
    $temp_file = $songs_file_abs . '.tmp';
    $result = file_put_contents($temp_file, $json_data, LOCK_EX); // 独占锁定

    if ($result === false) {
        error_log("Error writing to temporary songs.json file: {$temp_file}");
        return false;
    }
    // 原子性替换旧文件
    if (!rename($temp_file, $songs_file_abs)) {
        error_log("Error renaming temporary songs.json to final file.");
        unlink($temp_file); // 如果重命名失败，清理临时文件
        return false;
    }
    // 更新权限以防万一
    chmod($songs_file_abs, 0664); // 所有者读写，组读，其他人读
    return true;
}

// 格式化秒数为 H:MM:SS 或 MM:SS
function formatTime($seconds) {
    $seconds = (int) $seconds;
    if ($seconds < 0) return '0:00';
    $hours = floor($seconds / 3600);
    $minutes = floor(($seconds % 3600) / 60);
    $remaining_seconds = $seconds % 60;

    if ($hours > 0) {
        return sprintf('%d:%02d:%02d', $hours, $minutes, $remaining_seconds);
    } else {
        return sprintf('%d:%02d', $minutes, $remaining_seconds);
    }
}

// 格式化字节为可读单位
function formatBytes($bytes, $precision = 2) {
    $units = array('B', 'KB', 'MB', 'GB', 'TB');
    for ($i = 0; $bytes > 1024 && $i < count($units) - 1; $i++) {
        $bytes /= 1024;
    }
    return round($bytes, $precision) . ' ' . $units[$i];
}

// 检查文件扩展名是否允许
function allowedFile($filename) {
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    return in_array($ext, ALLOWED_EXTENSIONS);
}

// 生成唯一ID
function generateUniqueId() {
    return uniqid('', true) . bin2hex(random_bytes(4));
}

// 发送JSON响应
function sendJsonResponse(array $data, $status_code = 200) {
    http_response_code($status_code);
    header('Content-Type: application/json');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

// 扫描音乐目录并更新歌曲列表 (此功能目前主要用于初始化或清理)
function scanMusicDirectory() {
    $scanned_songs = [];
    $getID3 = new getID3;
    $upload_dir_abs = __DIR__ . '/' . UPLOAD_DIR;
    $covers_dir_abs = __DIR__ . '/' . COVERS_DIR;


    if (!is_dir($upload_dir_abs) || !is_readable($upload_dir_abs)) {
        error_log("Music upload directory not found or not readable: " . $upload_dir_abs);
        return [];
    }

    $files = scandir($upload_dir_abs);
    foreach ($files as $file) {
        if ($file === '.' || $file === '..') {
            continue;
        }

        $filepath = $upload_dir_abs . $file;
        if (is_file($filepath) && is_readable($filepath) && allowedFile($file)) {
            // Assume the unique_id is the filename without extension (e.g., '12345.mp3' -> '12345')
            $unique_id = pathinfo($file, PATHINFO_FILENAME);
            $music_filename = $file;
            $cover_filename = null; // Default to null, will be set if found/extracted

            try {
                $file_info = $getID3->analyze($filepath);
                if (isset($file_info['error'])) { error_log("getID3 error for {$file}: " . implode('; ', $file_info['error'])); }
                if (isset($file_info['warning'])) { error_log("getID3 warning for {$file}: " . implode('; ', $file_info['warning'])); }

                // Extract metadata (prioritizing ID3v2 over ID3v1)
                $title = $file_info['tags']['id3v2']['title'][0] ?? $file_info['tags']['id3v1']['title'][0] ?? pathinfo($file, PATHINFO_FILENAME);
                $artist = $file_info['tags']['id3v2']['artist'][0] ?? $file_info['tags']['id3v1']['artist'][0] ?? '未知艺术家';
                $album = $file_info['tags']['id3v2']['album'][0] ?? $file_info['tags']['id3v1']['album'][0] ?? '未知专辑';
                $duration_seconds = $file_info['playtime_seconds'] ?? 0;
                $duration_formatted = formatTime($duration_seconds);

                // Attempt to extract embedded cover image
                if (isset($file_info['comments']['picture'][0]['data'])) {
                    $cover_data = $file_info['comments']['picture'][0]['data'];
                    $cover_mime = $file_info['comments']['picture'][0]['image_mime'];
                    $cover_extension = 'jpg'; // Default to jpg
                    if (strpos($cover_mime, 'png') !== false) $cover_extension = 'png';
                    elseif (strpos($cover_mime, 'gif') !== false) $cover_extension = 'gif';

                    $potential_cover_filename = $unique_id . '_cover.' . $cover_extension;
                    $potential_cover_filepath = $covers_dir_abs . $potential_cover_filename;

                    // Only write if the cover file doesn't exist or is empty
                    if (!file_exists($potential_cover_filepath) || filesize($potential_cover_filepath) == 0) {
                        if (!is_writable($covers_dir_abs)) {
                            error_log("COVERS_DIR is not writable during scan. Skipping cover save for {$file}.");
                        } else {
                            if (file_put_contents($potential_cover_filepath, $cover_data) !== false) {
                                $cover_filename = $potential_cover_filename;
                            } else {
                                error_log("Failed to save cover for {$file} during scan.");
                            }
                        }
                    } else {
                        // If cover already exists, use its filename
                        $cover_filename = $potential_cover_filename;
                    }
                } else {
                     // If no embedded cover, check for existing cover files in covers/ folder
                     $existing_covers = glob($covers_dir_abs . $unique_id . '_cover.*');
                     if (!empty($existing_covers)) {
                         $cover_filename = basename($existing_covers[0]); // Take the first matching one
                     }
                }

                $scanned_songs[] = [
                    'id' => $unique_id,
                    'music_filename' => $music_filename, // This marks it as a local file
                    'original_filename' => $music_filename, // The actual filename on disk is the original_filename
                    'cover_filename' => $cover_filename,
                    'title' => $title,
                    'artist' => $artist,
                    'album' => $album,
                    'duration' => $duration_formatted,
                    'duration_seconds' => $duration_seconds
                ];

            } catch (Exception $e) {
                error_log("Error scanning metadata for {$file}: " . $e->getMessage());
                // If metadata extraction fails, add the song with default/filename-based info
                $scanned_songs[] = [
                    'id' => $unique_id,
                    'music_filename' => $music_filename,
                    'original_filename' => $music_filename,
                    'cover_filename' => null,
                    'title' => pathinfo($file, PATHINFO_FILENAME),
                    'artist' => '未知艺术家',
                    'album' => '未知专辑',
                    'duration' => '0:00',
                    'duration_seconds' => 0
                ];
            }
        }
    }
    return $scanned_songs;
}


// --- API 端点处理 ---
// 检查脚本是否直接被调用或通过 action 参数调用
if (basename(__FILE__) === basename($_SERVER['SCRIPT_FILENAME']) || isset($_REQUEST['action'])) {
    $method = $_SERVER['REQUEST_METHOD']; // 获取请求方法 (GET, POST, DELETE 等)
    $action = $_GET['action'] ?? '';     // 获取 action 参数

    switch ($action) {
        case 'list':
            if ($method === 'GET') {
                $songs = loadSongs();

                // 如果 songs.json 为空或似乎损坏，尝试通过扫描音乐目录来重建
                if (empty($songs) && (!file_exists(__DIR__ . '/' . SONGS_FILE) || filesize(__DIR__ . '/' . SONGS_FILE) == 0)) {
                    error_log("songs.json is empty or invalid. Attempting to scan music directory.");
                    $scanned_songs = scanMusicDirectory();
                    if (!empty($scanned_songs)) {
                        if (saveSongs($scanned_songs)) {
                             error_log("Rebuilt songs.json successfully from scan.");
                             $songs = $scanned_songs;
                        } else {
                             error_log("Failed to save rebuilt songs.json. Returning scanned list anyway.");
                             $songs = $scanned_songs;
                        }
                    } else {
                         error_log("Scan completed but found no valid music files.");
                         // 如果 songs.json 存在但为空/损坏，且扫描也未发现任何内容，
                         // 确保 songs.json 是一个空数组以反映真实状态。
                         if(file_exists(__DIR__ . '/' . SONGS_FILE) && filesize(__DIR__ . '/' . SONGS_FILE) > 0 && loadSongs() === []) {
                              error_log("songs.json exists but is corrupt/empty, and scan found no songs. Clearing corrupt json file.");
                              saveSongs([]);
                         }
                         $songs = []; // 确保 $songs 是一个空数组，如果没有找到任何内容
                    }
                }

                $songs_for_response = [];
                // 动态获取基础 URL 前缀，例如 http://localhost/yy/
                $base_url_prefix = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://{$_SERVER['HTTP_HOST']}/yy/";

                foreach ($songs as $song) {
                    $song_with_url = $song;
                    // 判断是本地文件还是外部链接
                    if (isset($song['music_filename'])) { // 本地文件
                        $song_with_url['url'] = $base_url_prefix . 'backend.php?action=serve_music&file=' . urlencode($song['music_filename']);
                        $song_with_url['cover_url'] = ($song['cover_filename'] ?? null) ? $base_url_prefix . 'backend.php?action=serve_cover&file=' . urlencode($song['cover_filename']) : null;
                        // 确保 duration_seconds 始终设置，用于前端计算
                        $song_with_url['duration_seconds'] = $song['duration_seconds'] ?? 0;
                    } elseif (isset($song['external_url'])) { // 外部链接
                        $song_with_url['url'] = $song['external_url'];
                        $song_with_url['cover_url'] = null; // 外部链接没有服务器管理的封面
                        // 对于外部链接，通常无法提前知道时长或封面，除非额外抓取（复杂）
                        $song_with_url['duration'] = '0:00'; // 占位符，浏览器会更新
                        $song_with_url['duration_seconds'] = $song['duration_seconds'] ?? 0; // 确保已设置，即使为 0
                    } else {
                         // 跳过格式不正确、既非本地文件也非外部链接的条目
                         error_log("Skipping malformed song entry in list (missing music_filename or external_url): " . json_encode($song));
                         continue;
                    }
                    $songs_for_response[] = $song_with_url;
                }
                sendJsonResponse($songs_for_response);

            } else {
                sendJsonResponse(['error' => 'Method Not Allowed'], 405);
            }
            break;

        case 'upload':
            if ($method === 'POST') {
                // 检查是否有上传文件或文件输入名称是否正确
                if (empty($_FILES['music_file']['name'][0])) {
                     sendJsonResponse(['error' => 'No file uploaded or wrong input name (expecting "music_file[]" for multiple or "music_file" for single)'], 400);
                }

                $uploaded_files = $_FILES['music_file'];
                // 规范化单文件或多文件上传的 $_FILES 结构
                if (!is_array($uploaded_files['name'])) {
                    $uploaded_files = [
                        'name' => [$uploaded_files['name']],
                        'type' => [$uploaded_files['type']],
                        'tmp_name' => [$uploaded_files['tmp_name']],
                        'error' => [$uploaded_files['error']],
                        'size' => [$uploaded_files['size']]
                    ];
                }

                $files_count = count($uploaded_files['name']);
                $uploaded_songs_info = []; // 存储成功上传/处理的歌曲详情
                $songs = loadSongs(); // 加载现有歌曲
                $getID3 = new getID3; // 初始化 getID3

                $upload_dir_abs = __DIR__ . '/' . UPLOAD_DIR;
                $covers_dir_abs = __DIR__ . '/' . COVERS_DIR;
                $base_url_prefix = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://{$_SERVER['HTTP_HOST']}/yy/"; // 动态获取基础 URL

                for ($i = 0; $i < $files_count; $i++) {
                     // 对每个文件条目进行基本检查
                     if (!isset($uploaded_files['name'][$i], $uploaded_files['tmp_name'][$i], $uploaded_files['error'][$i])) {
                          error_log("Skipping invalid uploaded file entry at index: {$i}");
                          continue;
                     }

                    $error = $uploaded_files['error'][$i];
                    $temp_path = $uploaded_files['tmp_name'][$i];
                    $original_name = $uploaded_files['name'][$i];

                    if ($error !== UPLOAD_ERR_OK) {
                        error_log("File upload error for '{$original_name}': Code {$error}");
                        continue; // 跳过此文件
                    }
                    if (!is_uploaded_file($temp_path)) {
                         error_log("Potential file upload attack: '{$original_name}' not a valid uploaded file.");
                         continue;
                    }
                    if (!allowedFile($original_name)) {
                        error_log("Disallowed file extension for '{$original_name}'.");
                        continue;
                    }

                    $unique_id = generateUniqueId();
                    $file_extension = strtolower(pathinfo($original_name, PATHINFO_EXTENSION));
                    $music_filename = $unique_id . '.' . $file_extension;
                    $music_filepath = $upload_dir_abs . $music_filename;
                    $cover_filename = null; // 如果封面被提取/找到，将设置此值

                     if (!is_writable($upload_dir_abs)) {
                         error_log("UPLOAD_DIR '{$upload_dir_abs}' is not writable. Cannot move uploaded file.");
                         // 对于多文件上传，不立即退出，只记录并跳过此文件。
                         continue;
                     }

                    if (move_uploaded_file($temp_path, $music_filepath)) {
                        try {
                             if (!is_readable($music_filepath)) {
                                 error_log("Uploaded file '{$music_filepath}' not readable after move. Skipping metadata extraction.");
                                 throw new Exception("File not readable for metadata extraction.");
                             }
                            $file_info = $getID3->analyze($music_filepath);
                            if (isset($file_info['error'])) { error_log("getID3 error for '{$music_filename}': " . implode('; ', $file_info['error'])); }
                            if (isset($file_info['warning'])) { error_log("getID3 warning for '{$music_filename}': " . implode('; ', $file_info['warning'])); }

                            // 提取元数据（ID3v2 优先于 ID3v1），并设置回退
                            $title = $file_info['tags']['id3v2']['title'][0] ?? $file_info['tags']['id3v1']['title'][0] ?? pathinfo($original_name, PATHINFO_FILENAME);
                            $artist = $file_info['tags']['id3v2']['artist'][0] ?? $file_info['tags']['id3v1']['artist'][0] ?? '未知艺术家';
                            $album = $file_info['tags']['id3v2']['album'][0] ?? $file_info['tags']['id3v1']['album'][0] ?? '未知专辑';
                            $duration_seconds = $file_info['playtime_seconds'] ?? 0;
                            $duration_formatted = formatTime($duration_seconds);

                            // 提取并保存嵌入的封面
                            if (isset($file_info['comments']['picture'][0]['data'])) {
                                $cover_data = $file_info['comments']['picture'][0]['data'];
                                $cover_mime = $file_info['comments']['picture'][0]['image_mime'];
                                $cover_extension = 'jpg'; // 默认 jpg
                                if (strpos($cover_mime, 'png') !== false) $cover_extension = 'png';
                                elseif (strpos($cover_mime, 'gif') !== false) $cover_extension = 'gif';

                                $cover_filename = $unique_id . '_cover.' . $cover_extension;
                                $cover_filepath = $covers_dir_abs . $cover_filename;

                                 if (!is_writable($covers_dir_abs)) {
                                     error_log("COVERS_DIR '{$covers_dir_abs}' is not writable. Skipping cover save for '{$music_filename}'.");
                                     $cover_filename = null; // 如果无法保存，不记录封面文件名
                                 } else {
                                    if (file_put_contents($cover_filepath, $cover_data) === false) {
                                        error_log("Failed to save cover for '{$music_filename}' to '{$cover_filepath}'.");
                                        $cover_filename = null;
                                    }
                                 }
                            }

                            // 创建新的歌曲条目
                            $new_song = [
                                'id' => $unique_id,
                                'music_filename' => $music_filename, // 标记为本地文件
                                'original_filename' => $original_name,
                                'cover_filename' => $cover_filename,
                                'title' => $title,
                                'artist' => $artist,
                                'album' => $album,
                                'duration' => $duration_formatted,
                                'duration_seconds' => $duration_seconds
                            ];
                            $songs[] = $new_song; // 添加到现有歌曲列表

                            // 添加到 uploaded_songs_info 以便响应
                            $uploaded_songs_info[] = [
                                'id' => $unique_id,
                                'title' => $title,
                                'artist' => $artist,
                                'album' => $album, // 响应中包含专辑
                                'duration' => $duration_formatted,
                                'duration_seconds' => $duration_seconds,
                                'url' => $base_url_prefix . 'backend.php?action=serve_music&file=' . urlencode($music_filename),
                                'cover_url' => $cover_filename ? $base_url_prefix . 'backend.php?action=serve_cover&file=' . urlencode($cover_filename) : null
                            ];

                        } catch (Exception $e) {
                            error_log("Error processing metadata for '{$music_filename}': " . $e->getMessage());
                            // 如果元数据提取失败，添加默认/基于文件名信息
                            $songs[] = [
                                'id' => $unique_id,
                                'music_filename' => $music_filename,
                                'original_filename' => $original_name,
                                'cover_filename' => null,
                                'title' => pathinfo($original_name, PATHINFO_FILENAME),
                                'artist' => '未知艺术家',
                                'album' => '未知专辑',
                                'duration' => '0:00',
                                'duration_seconds' => 0
                            ];
                            $uploaded_songs_info[] = [
                                'id' => $unique_id,
                                'title' => pathinfo($original_name, PATHINFO_FILENAME),
                                'artist' => '未知艺术家',
                                'album' => '未知专辑',
                                'duration' => '0:00',
                                'duration_seconds' => 0,
                                'url' => $base_url_prefix . 'backend.php?action=serve_music&file=' . urlencode($music_filename),
                                'cover_url' => null
                            ];
                        }

                    } else {
                        error_log("Failed to move uploaded file '{$original_name}' to '{$music_filepath}'.");
                    }
                }

                // 保存更新后的歌曲列表 (处理完所有文件后)
                if (!empty($uploaded_songs_info)) { // 只有至少一个歌曲成功处理才保存
                    if (saveSongs($songs)) {
                        error_log("Songs list saved after upload.");
                    } else {
                        error_log("Failed to save songs list after upload.");
                        // 即使保存失败，如果文件已移动，也返回已处理的歌曲信息。
                    }
                    sendJsonResponse(['message' => 'Files processed', 'uploaded_songs' => $uploaded_songs_info]);
                } else {
                     sendJsonResponse(['error' => 'No files were successfully uploaded or processed. Check server logs for details.'], 400);
                }

            } else {
                sendJsonResponse(['error' => 'Method Not Allowed'], 405);
            }
            break;

        case 'serve_music':
            if ($method === 'GET') {
                $filename = $_GET['file'] ?? '';
                $safe_filename = basename($filename); // 清理文件名，防止目录遍历攻击
                $filepath = __DIR__ . '/' . UPLOAD_DIR . $safe_filename;

                if (!file_exists($filepath) || !is_file($filepath) || !is_readable($filepath)) {
                    error_log("Requested music file not found, not a file, or not readable: {$filepath}");
                    sendJsonResponse(['error' => 'File not found or not accessible'], 404);
                }

                $songs = loadSongs();
                $is_authorized = false;
                foreach ($songs as $song) {
                    // 检查文件名是否存在于我们的歌曲列表中，并且是本地文件
                    if (isset($song['music_filename']) && $song['music_filename'] === $safe_filename) {
                        $is_authorized = true;
                        break;
                    }
                }

                if (!$is_authorized) {
                    error_log("Attempted access to unauthorized music file: {$safe_filename}");
                    sendJsonResponse(['error' => 'File not authorized or not in song list'], 403);
                }

                $file_size = filesize($filepath);
                $mime_type = mime_content_type($filepath);
                // mime_content_type 失败或返回通用类型时的回退
                if ($mime_type === false || $mime_type === 'application/octet-stream') {
                    $ext = strtolower(pathinfo($safe_filename, PATHINFO_EXTENSION));
                    $mime_mapping = [
                        'mp3' => 'audio/mpeg', 'wav' => 'audio/wav', 'ogg' => 'audio/ogg',
                        'flac' => 'audio/flac', 'aac' => 'audio/aac',
                    ];
                    $mime_type = $mime_mapping[$ext] ?? 'application/octet-stream';
                    if ($mime_type === 'application/octet-stream') { error_log("Could not determine specific MIME type for {$safe_filename}, serving as octet-stream."); }
                    else { error_log("Guessed MIME type for {$safe_filename}: {$mime_type}"); }
                }

                header('Content-Type: ' . $mime_type);
                header('Accept-Ranges: bytes'); // 支持范围请求

                $range_header = $_SERVER['HTTP_RANGE'] ?? null;

                if ($range_header) {
                    // 解析范围头
                    if (preg_match('/^bytes=(\d+)-(\d*)$/i', $range_header, $matches)) {
                        $start_byte = (int)$matches[1];
                        $end_byte = isset($matches[2]) && $matches[2] !== '' ? (int)$matches[2] : $file_size - 1;

                        // 验证范围
                        if ($start_byte >= $file_size || ($end_byte !== '' && $start_byte > $end_byte)) {
                            http_response_code(416); // 范围不可满足
                            header("Content-Range: bytes */{$file_size}"); // 告知客户端总大小
                            exit;
                        }
                        $end_byte = min($end_byte, $file_size - 1); // 确保 end_byte 不超过文件大小
                        $content_length = $end_byte - $start_byte + 1;

                        http_response_code(206); // 部分内容
                        header("Content-Range: bytes {$start_byte}-{$end_byte}/{$file_size}");
                        header("Content-Length: {$content_length}");

                        $handle = fopen($filepath, 'rb');
                        if ($handle === false) { error_log("serve_music: Failed to open file handle for {$filepath}"); http_response_code(500); exit; }
                        fseek($handle, $start_byte); // 移动文件指针到开始字节
                        $bytes_to_read = $content_length;
                        while ($bytes_to_read > 0 && !feof($handle) && !connection_aborted()) {
                            $buffer_size = min(8192, $bytes_to_read); // 分块读取
                            $buffer = fread($handle, $buffer_size);
                            if ($buffer === false) { break; } // 读取错误
                            echo $buffer;
                            $bytes_to_read -= strlen($buffer);
                            flush(); // 立即发送输出到客户端
                        }
                        fclose($handle);
                    } elseif (preg_match('/^bytes=-(\d+)$/i', $range_header, $matches)) {
                        // 处理后缀范围请求 (例如 bytes=-100)
                        $suffix_length = (int)$matches[1];
                        $start_byte = max(0, $file_size - $suffix_length);
                        $end_byte = $file_size - 1;
                        $content_length = $end_byte - $start_byte + 1;

                        http_response_code(206);
                        header("Content-Range: bytes {$start_byte}-{$end_byte}/{$file_size}");
                        header("Content-Length: {$content_length}");

                        $handle = fopen($filepath, 'rb');
                        if ($handle === false) { error_log("serve_music: Failed to open file handle for {$filepath}"); http_response_code(500); exit; }
                        fseek($handle, $start_byte);
                        $bytes_to_read = $content_length;
                        while ($bytes_to_read > 0 && !feof($handle) && !connection_aborted()) {
                            $buffer_size = min(8192, $bytes_to_read);
                            $buffer = fread($handle, $buffer_size);
                            if ($buffer === false) { break; }
                            echo $buffer;
                            $bytes_to_read -= strlen($buffer);
                            flush();
                        }
                        fclose($handle);
                    } else {
                       error_log("serve_music: Unparseable Range header: {$range_header}");
                       http_response_code(416); header("Content-Range: bytes */{$file_size}"); exit;
                    }
                } else {
                    // 如果没有范围头，则提供完整文件
                    http_response_code(200);
                    header("Content-Length: {$file_size}");
                    readfile($filepath); // readfile 可以高效处理大文件
                }
                exit; // 确保没有其他输出
            } else {
                sendJsonResponse(['error' => 'Method Not Allowed'], 405);
            }
            break;

        case 'serve_cover':
            if ($method === 'GET') {
                 $filename = $_GET['file'] ?? '';
                 $safe_filename = basename($filename);
                 $filepath = __DIR__ . '/' . COVERS_DIR . $safe_filename;

                 if (file_exists($filepath) && is_file($filepath) && is_readable($filepath)) {
                      $songs = loadSongs();
                      $is_authorized = false;
                      foreach ($songs as $song) {
                          // 检查封面文件名是否存在于我们的歌曲列表中
                          if (($song['cover_filename'] ?? null) === $safe_filename) {
                              $is_authorized = true;
                              break;
                          }
                      }

                      if ($is_authorized) {
                         $mime_type = mime_content_type($filepath);
                         // 对图片 MIME 类型进行基本检查
                         if ($mime_type === false || strpos($mime_type, 'image/') !== 0) {
                             error_log("Detected non-image MIME type for cover '{$safe_filename}': {$mime_type}");
                             sendJsonResponse(['error' => 'Invalid cover file type or not recognized as image'], 415); // 不支持的媒体类型
                         } else {
                             header('Content-Type: ' . $mime_type);
                             header('Content-Length: ' . filesize($filepath));
                             readfile($filepath);
                             exit;
                         }
                      } else {
                          error_log("Attempted access to unauthorized cover file: '{$safe_filename}'.");
                          sendJsonResponse(['error' => 'Cover not authorized or not linked to a song'], 403);
                      }

                 } else {
                     error_log("Requested cover file not found, not a file, or not readable: '{$filepath}'.");
                     sendJsonResponse(['error' => 'Cover not found or not accessible'], 404);
                 }
            } else {
                sendJsonResponse(['error' => 'Method Not Allowed'], 405);
            }
            break;

        case 'delete':
            if ($method === 'DELETE') {
                $song_id = $_GET['id'] ?? '';

                if (empty($song_id)) { sendJsonResponse(['error' => 'Missing song ID'], 400); }

                $songs = loadSongs();
                $song_to_delete = null;
                $remaining_songs = []; // 用于构建不被删除的歌曲的新数组

                $found = false;
                foreach ($songs as $song) {
                    if (($song['id'] ?? null) === $song_id) {
                        $song_to_delete = $song;
                        $found = true;
                    } else {
                        $remaining_songs[] = $song; // 如果不是要删除的歌曲，则添加到新数组
                    }
                }

                if ($found && $song_to_delete) {
                    $upload_dir_abs = __DIR__ . '/' . UPLOAD_DIR;
                    $covers_dir_abs = __DIR__ . '/' . COVERS_DIR;

                    // 如果是本地文件，则删除它
                    if (isset($song_to_delete['music_filename'])) {
                        $music_filename = $song_to_delete['music_filename'] ?? '';
                        $music_filepath = $upload_dir_abs . $music_filename;
                        if (!empty($music_filename) && file_exists($music_filepath)) {
                            if (!unlink($music_filepath)) { error_log("Failed to delete music file: '{$music_filepath}'"); } else { error_log("Deleted music file: '{$music_filepath}'"); }
                        } else { error_log("Music file not found or filename missing in record when trying to delete: '{$music_filepath}'"); }

                        $cover_filename = $song_to_delete['cover_filename'] ?? '';
                        if (!empty($cover_filename)) {
                             $cover_filepath = $covers_dir_abs . $cover_filename;
                             if (file_exists($cover_filepath)) {
                                 if (!unlink($cover_filepath)) { error_log("Failed to delete cover file: '{$cover_filepath}'"); } else { error_log("Deleted cover file: '{$cover_filepath}'"); }
                             } else { error_log("Cover file not found when trying to delete: '{$cover_filepath}'"); }
                        }
                    }
                    // 对于外部链接，没有物理文件要删除，只需从列表中移除。

                    // 保存已移除歌曲的更新列表
                    if (saveSongs($remaining_songs)) {
                       error_log("Deleted song (ID: {$song_id}) from songs.json successfully.");
                       sendJsonResponse(['message' => "Song deleted successfully"], 200);
                    } else {
                       error_log("Failed to update songs.json after deleting song (ID: {$song_id}).");
                       sendJsonResponse(['error' => "Failed to update song list after deleting song (ID: {$song_id}). Files might still exist."], 500);
                    }

                } else {
                    sendJsonResponse(['error' => "Song with ID {$song_id} not found in list"], 404);
                }

            } else {
                 sendJsonResponse(['error' => 'Method Not Allowed'], 405);
            }
            break;

        // --- 添加 URL (不下载，直接播放) ---
        case 'add_url':
            if ($method === 'POST') {
                $input = json_decode(file_get_contents('php://input'), true);

                $url = $input['url'] ?? '';
                $custom_title = $input['title'] ?? null;
                $custom_artist = $input['artist'] ?? null;

                if (empty($url)) {
                    sendJsonResponse(['error' => 'URL is required'], 400);
                }
                if (!filter_var($url, FILTER_VALIDATE_URL)) {
                    sendJsonResponse(['error' => 'Invalid URL format'], 400);
                }
                if (!preg_match('/^https?:\/\//i', $url)) {
                    sendJsonResponse(['error' => 'Only HTTP or HTTPS URLs are allowed'], 400);
                }

                $songs = loadSongs();
                $unique_id = generateUniqueId();
                // 如果提供了自定义标题/艺术家，则使用；否则尝试从 URL 提取
                $title = $custom_title ?: basename(parse_url($url, PHP_URL_PATH) ?: '未知歌曲');
                $artist = $custom_artist ?: '未知艺术家';

                $new_song = [
                    'id' => $unique_id,
                    'external_url' => $url, // 直接存储 URL，表示这是一个外部链接
                    'title' => $title,
                    'artist' => $artist,
                    'album' => '外部链接', // 外部链接的默认专辑
                    'duration' => '0:00', // 前端通常通过 Audio API 获取实际时长
                    'duration_seconds' => 0, // 前端通常通过 Audio API 获取实际时长
                    // 外部 URL 没有 'music_filename' 或 'cover_filename'
                ];
                $songs[] = $new_song;

                if (saveSongs($songs)) {
                    sendJsonResponse(['message' => 'External URL added successfully', 'song' => $new_song]);
                } else {
                    sendJsonResponse(['error' => 'Failed to save song list after adding URL'], 500);
                }

            } else {
                sendJsonResponse(['error' => 'Method Not Allowed'], 405);
            }
            break;
            
        // --- 从 URL 添加（下载文件到服务器） ---
        case 'add_by_url':
            if ($method === 'POST') {
                $input_url = $_POST['url'] ?? '';
                $custom_title = $_POST['title'] ?? null;
                $custom_artist = $_POST['artist'] ?? null;
                $custom_album = $_POST['album'] ?? null; // 允许为下载的文件自定义专辑

                if (empty($input_url)) {
                    sendJsonResponse(['error' => 'URL is required'], 400);
                }
                if (!filter_var($input_url, FILTER_VALIDATE_URL)) {
                    sendJsonResponse(['error' => 'Invalid URL format'], 400);
                }
                if (!preg_match('/^https?:\/\//i', $input_url)) {
                    sendJsonResponse(['error' => 'Only HTTP or HTTPS URLs are allowed for download'], 400);
                }

                // 从 URL 获取文件扩展名
                $url_path = parse_url($input_url, PHP_URL_PATH);
                $file_extension = strtolower(pathinfo($url_path, PATHINFO_EXTENSION));

                if (!in_array($file_extension, ALLOWED_EXTENSIONS)) {
    sendJsonResponse(['error' => 'Disallowed file extension: ' . $file_extension . '. Allowed: ' . implode(', ', ALLOWED_EXTENSIONS)], 400);
}

                $unique_id = generateUniqueId();
                $music_filename = $unique_id . '.' . $file_extension;
                $music_filepath = __DIR__ . '/' . UPLOAD_DIR . $music_filename;

                // 检查上传目录是否可写
                if (!is_writable(__DIR__ . '/' . UPLOAD_DIR)) {
                    sendJsonResponse(['error' => 'Upload directory is not writable. Cannot download file.'], 500);
                }

                // 下载文件
                $download_success = false;
                $ch = curl_init();
                try {
                    curl_setopt($ch, CURLOPT_URL, $input_url);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // 返回传输内容而不是直接输出
                    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); // 跟随任何重定向
                    curl_setopt($ch, CURLOPT_MAXREDIRS, 5); // 最大重定向次数
                    curl_setopt($ch, CURLOPT_TIMEOUT, 30); // 头部/初始连接超时 30 秒
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // 在生产环境中，考虑设置为 true 并配置 CA 证书
                    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false); // 在生产环境中，考虑设置为 2

                    // --- 关键修复：添加 User-Agent 和 Referer 请求头以模拟浏览器 ---
                    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36');
                    // 使用合理的回溯 URL，例如音乐服务的基础域名
                    $referer_url = parse_url($input_url);
                    $base_domain = (isset($referer_url['scheme']) ? $referer_url['scheme'] . '://' : '') . (isset($referer_url['host']) ? $referer_url['host'] : '');
                    curl_setopt($ch, CURLOPT_REFERER, $base_domain);
                    // --- 关键修复结束 ---


                    // 首先从头部获取文件大小
                    curl_setopt($ch, CURLOPT_NOBODY, true); // 只获取头部
                    curl_setopt($ch, CURLOPT_HEADER, true); // 返回头部信息
                    $header_response = curl_exec($ch);
                    $header_info = curl_getinfo($ch);

                    if (curl_errno($ch)) {
                        throw new Exception("Curl error for headers: " . curl_error($ch));
                    }
                    if ($header_info['http_code'] !== 200) {
                        // 记录完整的 HTTP 响应，以便查看发生了什么
                        error_log("Download header check failed. HTTP Code: " . $header_info['http_code'] . ", URL: " . $input_url . ", Headers: " . $header_response);
                        throw new Exception("URL returned HTTP error: " . $header_info['http_code']);
                    }

                    $content_length = (int) ($header_info['download_content_length'] ?? 0);
                    if ($content_length > MAX_DOWNLOAD_SIZE && MAX_DOWNLOAD_SIZE > 0) {
                        throw new Exception('File size (' . formatBytes($content_length) . ') exceeds maximum allowed (' . formatBytes(MAX_DOWNLOAD_SIZE) . ')');
                    }
                    curl_close($ch); // 关闭只获取头部的 curl

                    // 重新初始化进行完整下载
                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_URL, $input_url);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                    curl_setopt($ch, CURLOPT_MAXREDIRS, 5);
                    curl_setopt($ch, CURLOPT_TIMEOUT, 120); // 实际下载设置更长的超时时间
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

                    // --- 关键修复：重新添加 User-Agent 和 Referer 进行实际下载请求 ---
                    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36');
                    curl_setopt($ch, CURLOPT_REFERER, $base_domain);
                    // --- 关键修复结束 ---

                    $file_content = curl_exec($ch);
                    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);

                    if (curl_errno($ch)) {
                        throw new Exception("Curl error for download: " . curl_error($ch));
                    }
                    if ($file_content === false || $http_code !== 200) {
                        error_log("Download failed. HTTP Code: " . $http_code . ", URL: " . $input_url);
                        throw new Exception('Failed to download file from URL. HTTP code: ' . $http_code);
                    }

                    if (file_put_contents($music_filepath, $file_content) === false) {
                        throw new Exception('Failed to save downloaded file to disk.');
                    }
                    $download_success = true;

                } catch (Exception $e) {
                    error_log("Error in add_by_url: " . $e->getMessage());
                    sendJsonResponse(['error' => '下载失败: ' . $e->getMessage()], 500);
                } finally {
                    if (is_resource($ch)) { // 确保 $ch 是一个资源才关闭
                        curl_close($ch);
                    }
                }

                if ($download_success) {
                    $getID3 = new getID3;
                    $cover_filename = null; // 如果封面被提取，将设置此值

                    try {
                        $file_info = $getID3->analyze($music_filepath);
                        if (isset($file_info['error'])) { error_log("getID3 error for downloaded file {$music_filename}: " . implode('; ', $file_info['error'])); }
                        if (isset($file_info['warning'])) { error_log("getID3 warning for downloaded file {$music_filename}: " . implode('; ', $file_info['warning'])); }

                        // 提取元数据（ID3v2 优先于 ID3v1）
                        $title = $custom_title ?: ($file_info['tags']['id3v2']['title'][0] ?? $file_info['tags']['id3v1']['title'][0] ?? pathinfo(basename($input_url), PATHINFO_FILENAME));
                        $artist = $custom_artist ?: ($file_info['tags']['id3v2']['artist'][0] ?? $file_info['tags']['id3v1']['artist'][0] ?? '未知艺术家');
                        $album = $custom_album ?: ($file_info['tags']['id3v2']['album'][0] ?? $file_info['tags']['id3v1']['album'][0] ?? '未知专辑');
                        $duration_seconds = $file_info['playtime_seconds'] ?? 0;
                        $duration_formatted = formatTime($duration_seconds);

                        // 尝试提取嵌入的封面图片
                        if (isset($file_info['comments']['picture'][0]['data'])) {
                            $cover_data = $file_info['comments']['picture'][0]['data'];
                            $cover_mime = $file_info['comments']['picture'][0]['image_mime'];
                            $cover_extension = 'jpg';
                            if (strpos($cover_mime, 'png') !== false) $cover_extension = 'png';
                            elseif (strpos($cover_mime, 'gif') !== false) $cover_extension = 'gif';

                            $cover_filename = $unique_id . '_cover.' . $cover_extension;
                            $cover_filepath = __DIR__ . '/' . COVERS_DIR . $cover_filename;

                            if (!is_writable(__DIR__ . '/' . COVERS_DIR)) {
                                error_log("COVERS_DIR is not writable. Skipping cover save for {$music_filename}.");
                                $cover_filename = null;
                            } else {
                                if (file_put_contents($cover_filepath, $cover_data) === false) {
                                    error_log("Failed to save cover for {$music_filename} to {$cover_filepath}.");
                                    $cover_filename = null;
                                }
                            }
                        }

                        $songs = loadSongs();
                        $new_song = [
                            'id' => $unique_id,
                            'music_filename' => $music_filename, // 标记为本地文件
                            'original_filename' => basename($input_url),
                            'cover_filename' => $cover_filename,
                            'title' => $title,
                            'artist' => $artist,
                            'album' => $album,
                            'duration' => $duration_formatted,
                            'duration_seconds' => $duration_seconds
                        ];
                        $songs[] = $new_song;

                        if (saveSongs($songs)) {
                            sendJsonResponse(['message' => '歌曲下载并添加成功！', 'song_id' => $unique_id]);
                        } else {
                            // 如果保存失败，尝试删除下载的文件以防止孤立文件
                            unlink($music_filepath);
                            if ($cover_filename && file_exists(__DIR__ . '/' . COVERS_DIR . $cover_filename)) {
                                unlink(__DIR__ . '/' . COVERS_DIR . $cover_filename);
                            }
                            sendJsonResponse(['error' => '歌曲下载成功，但保存到列表失败。文件已回滚。'], 500);
                        }

                    } catch (Exception $e) {
                        error_log("Error processing metadata for downloaded file {$music_filename}: " . $e->getMessage());
                        // 如果元数据提取失败，添加默认/基于文件名信息
                        $songs = loadSongs();
                        $songs[] = [
                            'id' => $unique_id,
                            'music_filename' => $music_filename,
                            'original_filename' => basename($input_url),
                            'cover_filename' => null,
                            'title' => $custom_title ?: pathinfo(basename($input_url), PATHINFO_FILENAME),
                            'artist' => $custom_artist ?: '未知艺术家',
                            'album' => $custom_album ?: '未知专辑',
                            'duration' => '0:00',
                            'duration_seconds' => 0
                        ];
                        if (saveSongs($songs)) {
                            sendJsonResponse(['message' => '歌曲下载成功，但元数据处理失败。已添加默认信息。', 'song_id' => $unique_id]);
                        } else {
                            unlink($music_filepath); // 如果甚至保存默认信息都失败，则删除文件
                            sendJsonResponse(['error' => '歌曲下载成功，但保存到列表失败且元数据处理失败。文件已回滚。'], 500);
                        }
                    }
                }
            } else {
                sendJsonResponse(['error' => 'Method Not Allowed'], 405);
            }
            break;
            
        // --- 获取单个歌曲信息 ---
        case 'get_song':
            if ($method === 'GET') {
                $song_id = $_GET['id'] ?? '';
                if (empty($song_id)) {
                    sendJsonResponse(['error' => 'Missing song ID'], 400);
                }

                $songs = loadSongs();
                foreach ($songs as $song) {
                    if (($song['id'] ?? null) === $song_id) {
                        // 返回只用于模态框的可编辑字段
                        sendJsonResponse([
                            'id' => $song['id'],
                            'title' => $song['title'] ?? '',
                            'artist' => $song['artist'] ?? '',
                            'album' => $song['album'] ?? ''
                        ]);
                    }
                }
                sendJsonResponse(['error' => "Song with ID {$song_id} not found"], 404);
            } else {
                sendJsonResponse(['error' => 'Method Not Allowed'], 405);
            }
            break;

        // --- 更新歌曲信息 ---
        case 'update_song':
            if ($method === 'POST') {
                // 从请求体读取 JSON 输入
                $input = json_decode(file_get_contents('php://input'), true);

                $song_id = $input['id'] ?? '';
                $new_title = $input['title'] ?? null;
                $new_artist = $input['artist'] ?? null;
                $new_album = $input['album'] ?? null;

                if (empty($song_id)) {
                    sendJsonResponse(['error' => 'Missing song ID for update'], 400);
                }

                $songs = loadSongs();
                $updated = false;

                foreach ($songs as $key => $song) {
                    if (($song['id'] ?? null) === $song_id) {
                        // 仅当输入中提供了字段且不为 null 时才更新
                        if ($new_title !== null) {
                            $songs[$key]['title'] = trim($new_title);
                        }
                        if ($new_artist !== null) {
                            $songs[$key]['artist'] = trim($new_artist);
                        }
                        if ($new_album !== null) {
                            $songs[$key]['album'] = trim($new_album);
                        }
                        $updated = true;
                        break;
                    }
                }

                if ($updated) {
                    if (saveSongs($songs)) {
                        sendJsonResponse(['message' => 'Song information updated successfully']);
                    } else {
                        sendJsonResponse(['error' => 'Failed to save updated song list'], 500);
                    }
                } else {
                    sendJsonResponse(['error' => "Song with ID {$song_id} not found or no changes applied"], 404);
                }
            } else {
                sendJsonResponse(['error' => 'Method Not Allowed'], 405);
            }
            break;

        // --- 清空所有歌曲 ---
        case 'delete_all':
            if ($method === 'POST') {
                $songs = loadSongs();
                $upload_dir_abs = __DIR__ . '/' . UPLOAD_DIR;
                $covers_dir_abs = __DIR__ . '/' . COVERS_DIR;

                foreach ($songs as $song) {
                    // 仅当是本地音乐文件时才删除物理文件
                    if (isset($song['music_filename']) && !empty($song['music_filename'])) {
                        $music_filepath = $upload_dir_abs . $song['music_filename'];
                        if (file_exists($music_filepath)) {
                            if (!unlink($music_filepath)) { error_log("Failed to delete music file during mass delete: {$music_filepath}"); }
                        }
                    }
                    if (isset($song['cover_filename']) && !empty($song['cover_filename'])) {
                        $cover_filepath = $covers_dir_abs . $song['cover_filename'];
                        if (file_exists($cover_filepath)) {
                            if (!unlink($cover_filepath)) { error_log("Failed to delete cover file during mass delete: {$cover_filepath}"); }
                        }
                    }
                }
                // 清空 songs.json 文件
                if (saveSongs([])) {
                    sendJsonResponse(['message' => 'All songs and associated files have been deleted.']);
                } else {
                    sendJsonResponse(['error' => 'Failed to clear song list (songs.json). Files might remain on disk.'], 500);
                }
            } else {
                sendJsonResponse(['error' => 'Method Not Allowed'], 405);
            }
            break;

        default:
            // 默认响应，列出可用 API 动作
            sendJsonResponse(['message' => 'Vinyl Player Backend API', 'available_actions' => ['list', 'upload', 'serve_music', 'serve_cover', 'delete', 'add_url', 'add_by_url', 'get_song', 'update_song', 'delete_all']], 200);
            break;
    }
}
?>
